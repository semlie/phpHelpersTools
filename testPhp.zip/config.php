<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
define('apiUrl', "http://crm.yaelzals.co.il/zurmo/app/index.php");

define("ApiKeyGetResponse", "5d18b610393c0135e638fb506d6cc9ed");
define("CrmUrl", "");
define("CrmUser", "super");
define("CrmPas", "1Chaya2Lieb3");
define("WPUser", "1_admin");
define("WPPas", "1Chaya2Lieb3");
//define("WPSiteUrl", "http://localhost/www/wp/xmlrpc.php");
define("WPSiteUrl", "http://ashira.co.il/xmlrpc.php");
define('WLaddress', 'http://course.yaelzals.co.il');
                
define('WLapikey', '3ca5df43cf08a82d1c886e4742fffe4b');